# GianellArt — Sitio web

Proyecto escolar realizado con HTML5, CSS3, Bootstrap CSS y Media Queries.

## No contiene JavaScript
No hay archivos `.js` ni código JavaScript. Bootstrap se usa mediante su hoja de estilos.

## Páginas
- index.html
- productos.html
- personalizados.html
- nosotros.html
- contacto.html

## Requisitos incluidos
- 5 páginas HTML independientes y enlazadas.
- HTML5 semántico: header, nav, main, section, article, aside y footer.
- Formulario con `name`, `placeholder`, `required`, `type="email"`, `type="tel"`, `type="date"`, select y textarea.
- Mobile-First y Media Queries.
- Flexbox para navegación/redes y CSS Grid para catálogo, servicios y valores.
- Bootstrap: Navbar, Carousel, Cards/Badges, Buttons, row/col y utilidades.
- SEO: description, keywords, Open Graph, viewport y canonical.
- Accesibilidad: alt descriptivos y labels.
- Filtros de productos con HTML + CSS, sin JavaScript.

## Importante sobre Bootstrap sin JavaScript
Los componentes interactivos oficiales de Bootstrap, como el navbar colapsable y el carousel automático, normalmente necesitan JavaScript. Como la consigna exige que este proyecto NO tenga JavaScript, el navbar se adapta con CSS y el carrusel usa clases de Bootstrap más desplazamiento CSS. Así se mantiene el requisito de no usar JavaScript.

## Publicar en GitHub Pages
1. Creá un repositorio público, por ejemplo `gianellart`.
2. Subí todos estos archivos respetando las carpetas.
3. Reemplazá `TU-USUARIO` en las etiquetas canonical/Open Graph por tu usuario real de GitHub.
4. En GitHub: Settings → Pages → Deploy from a branch → `main` → `/root`.
5. Guardá y esperá a que GitHub Pages publique el sitio.

## Personalizar antes de entregar
- Reemplazá el email de ejemplo.
- Agregá tu Instagram/WhatsApp real.
- Podés cambiar los precios de "Precio a consultar".
- Si tenés fotos reales de tus cuadros, reemplazá los SVG de ejemplo por tus fotografías.
